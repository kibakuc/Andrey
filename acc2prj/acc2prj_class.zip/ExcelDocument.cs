﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace acc2prj {
    class ExcelDocument : IDisposable {
        public Excel.Application application = null;
        public Excel.Workbook workBook = null;
        public Excel.Worksheet workSheet = null;

        private object missingObj = System.Reflection.Missing.Value;
        private bool disposed = false;


        public ExcelDocument() {
            application = new Excel.Application();
            workBook = application.Workbooks.Add(missingObj);
            workSheet = (Excel.Worksheet)workBook.Worksheets.get_Item(1);
        }

        public ExcelDocument(string pathToTemplate) {
            object pathToTemplateObj = pathToTemplate;
            application = new Excel.Application();
            workBook = application.Workbooks.Add(pathToTemplateObj);
            workSheet = (Excel.Worksheet)workBook.Worksheets.get_Item(1);
            //Cells cells = workSheet.Cells;
        }

        ~ExcelDocument() {
            //Console.WriteLine("Finalized");
            this.Dispose();
        }

        public void Dispose() {
            if (!this.disposed) {
                //Console.WriteLine("Disposed");
                Close();
            }
            this.disposed = true;
            GC.SuppressFinalize(this);
        }

        public bool Visible {
            get {
                return application.Visible;
            }
            set {
                application.Visible = value;
                /*                if (value)
                                    workBook.Activate();
                */
            }
        }

        public void SetCellValue(string cellValue, int rowIndex, int columnIndex) {
            workSheet.Cells[rowIndex, columnIndex].Value = cellValue;
        }
        public void SetCustomFormat(string format, int rowIndex, int columnIndex) {
            ((Excel.Range)workSheet.Cells[rowIndex, columnIndex]).NumberFormat = format;
            //workSheet.Cells[rowIndex, columnIndex].NumberFormat = format;
        }

        public string GetCellValue(int rowIndex, int columnIndex) {
            string cellValue = "";
            cellValue = workSheet.Cells[rowIndex, columnIndex].Text;
            return cellValue;
        }
        public int RowsWithDataCount {
            get {
                int usedRowsNum = 0;
                usedRowsNum = workSheet.UsedRange.Rows.Count;
                return usedRowsNum;
            }
        }

        public int ColumnsWithDataCount {
            get {
                int usedColumnsNum = 0;
                usedColumnsNum = workSheet.UsedRange.Columns.Count;
                return usedColumnsNum;
            }
        }
        private void Close() {
            workBook.Close(false, missingObj, missingObj);
            application.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(application);
            application = null;
            workBook = null;
            workSheet = null;
            //System.GC.Collect();
        }


    }
}
