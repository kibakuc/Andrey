﻿
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace acc2prj {
    class OraDatabase {
        //https://www.oracle.com/webfolder/technetwork/tutorials/obe/db/dotnet/GettingStartedNETVersion/GettingStartedNETVersion.htm
        //https://o7planning.org/ru/10519/working-with-oracle-database-using-csharp#a1815145
        //https://docs.microsoft.com/en-us/dotnet/api/system.data.oracleclient.oracletransaction?view=netframework-4.8
        //https://pravsdatums.wordpress.com/2014/01/30/simple-dataaccess-class-for-c-and-oracle/
        //https://codereview.stackexchange.com/questions/194954/calling-an-oracle-stored-procedure-with-c-code
        //https://www.c-sharpcorner.com/article/calling-oracle-stored-procedures-from-microsoft-net/
        OracleConnection conn;
        //OracleTransaction tran;
        //OracleCommand cmd;
        private string ConnectionString;

        public OraDatabase() {
            ConnectionString = "";
        }

        public OraDatabase(string host, int port, String sid, String user, String password) {
            ConnectionString = "Data Source=(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = "
                 + host + ")(PORT = " + port + "))(CONNECT_DATA = (SERVER = DEDICATED)(SERVICE_NAME = "
                 + sid + ")));Password=" + password + ";User ID=" + user;
        }

        public void OpenConection() {
            conn = new OracleConnection(ConnectionString);
            conn.Open();
        }

        public void CloseConnection() {
            conn.Close();
        }

        public OracleCommand ReturnOraCommand(string SqlStr) {
            OracleCommand cmd = new OracleCommand(SqlStr, conn);
            return cmd;
        }

        /*      

                OracleTransaction tran;
                tran = conn.BeginTransaction(IsolationLevel.ReadCommitted);
                cmd.Transaction = tran;
                try {
                    cmd.CommandText = "INSERT INTO Dept (DeptNo, Dname, Loc) values (50, 'TECHNOLOGY', 'DENVER')";
                    cmd.ExecuteNonQuery();
                    tran.Commit();
                } catch (Exception e) {
                    transaction.Rollback();
                }
        */
    }
}
