﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Lab12 {
    public partial class Form1 : Form {
        ArrayList product;
        DataTable dt;
        DataRow dr;
        DataSet ds;

        public Form1() {
            InitializeComponent();
            product = new ArrayList();
            product.Add(new Product(product.Count, "name1", 20));
            product.Add(new Product(product.Count, "name2", 21));
            product.Add(new Product(product.Count, "name3", 22));

            ds = new DataSet();
            dt = new DataTable();
            dt.Columns.Add(new DataColumn("ID", Type.GetType("System.Int32")));
            dt.Columns.Add(new DataColumn("Name", Type.GetType("System.String")));
            dt.Columns.Add(new DataColumn("Price", Type.GetType("System.Int32")));

            for (int i = 0; i < product.Count; i++) {
                dr = dt.NewRow();
                dr["ID"] = ((Product)(product[i])).Id;
                dr["Name"] = ((Product)(product[i])).Name;
                dr["Price"] = ((Product)(product[i])).Price;
                dt.Rows.Add(dr);
            }
            ds.Tables.Add(dt);
            ds.Tables[0].TableName = "Product";
            FileInfo f = new FileInfo("product.xml");

            if (!f.Exists) {
                Serializer.WriteXML("product.xml", ds);
            }
            ds = Serializer.ReadXML("product.xml");
            GridView1.DataSource = ds.Tables[0];
            Name1.Text = GridView1.Rows[0].Cells["Name"].Value.ToString();
            Price1.Text = GridView1.Rows[0].Cells["Price"].Value.ToString();

        }

        private void GridView1_CellClick(object sender, DataGridViewCellEventArgs e) {
            //MessageBox.Show(e.RowIndex.ToString());
            if (e.RowIndex >= 0) {
                Name1.Text = GridView1.Rows[e.RowIndex].Cells["Name"].Value.ToString();
                Price1.Text = GridView1.Rows[e.RowIndex].Cells["Price"].Value.ToString();
            }
        }

        private void GridView1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e) {
            if (e.RowIndex < 0) {
                Name1.Text = GridView1.Rows[0].Cells["Name"].Value.ToString();
                Price1.Text = GridView1.Rows[0].Cells["Price"].Value.ToString();
            }
        }

        private void Button1_Click(object sender, EventArgs e) {
            product.Add(new Product(product.Count, Name1.Text.Trim(), Convert.ToInt32(Price1.Text.Trim())));
            DataRow dr = ds.Tables[0].NewRow();
            dr["ID"] = ((Product)(product[product.Count - 1])).Id;
            dr["Name"] = ((Product)(product[product.Count - 1])).Name;
            dr["Price"] = ((Product)(product[product.Count - 1])).Price;
            ds.Tables[0].Rows.Add(dr);
            Serializer.WriteXML("product.xml", ds);
        }

        private void Button2_Click(object sender, EventArgs e) {

            MessageBox.Show((GridView1.Rows.Count - 1).ToString());
            //Serializer.WriteXML("product.xml", ds);
        }
    }




}
